#include <Math/UnaryOperators.h>

void SetLeafAddress(TTree* ntuple, const char* name, void* address);


void PS_analysis()
{
  // Reading the input file
  TFile *file_input = TFile::Open("PSPET.root");
    
  // Reading the data (in TTree format)
  TTree *PSPET =(TTree *) file_input->Get("PSPET; 1");
  
  bool rowWise = true;
    
  //TBranch* eventBranch = PSPET->FindBranch("row_wise_branch");
  
  //if (! eventBranch) rowWise = false;
        
  //Setting up your variables that you want to read from the data
  double Edep;
  double X;
  double Y;
  double Z;
  
  double X_first; 
  double Y_first; 
  double Z_first; 
  double X_second; 
  double Y_second; 
  double Z_second; 
  double distance;
  // double KineticEne;
  // double Angle;
    
  // Connect these variables to the one in the TTree data
  if (!rowWise)
  {
   PSPET->SetBranchAddress("Edep", &Edep);
   PSPET->SetBranchAddress("X", &X);
   PSPET->SetBranchAddress("Y", &Y);
   PSPET->SetBranchAddress("Z", &Z);
   PSPET->SetBranchAddress("X_first",&X_first);
   PSPET->SetBranchAddress("Y_first",&Y_first);
   PSPET->SetBranchAddress("Z_first",&Z_first);
   PSPET->SetBranchAddress("X_second",&X_second);
   PSPET->SetBranchAddress("Y_second",&Y_second);
   PSPET->SetBranchAddress("Z_second",&Z_second);// positions are recorded in mm
  }
  
  else
  {
  SetLeafAddress(PSPET,"Edep", &Edep);
   SetLeafAddress(PSPET, "X", &X);
   SetLeafAddress(PSPET, "Y", &Y);
   SetLeafAddress(PSPET, "Z", &Z);
   SetLeafAddress(PSPET,"X_first", &X_first);
   SetLeafAddress(PSPET,"Y_first", &Y_first);
   SetLeafAddress(PSPET,"Z_first", &Z_first);
   SetLeafAddress(PSPET,"X_second",&X_second);
   SetLeafAddress(PSPET,"Y_second",&Y_second);
   SetLeafAddress(PSPET,"Z_second",&Z_second);
  }
    
   int entries = PSPET->GetEntries();

   cout << entries << endl;
   

   // two histograms
   TH1F *r   = new TH1F("r","Distance between two Compton scattering",500,0,600);
   TH1F *angle   = new TH1F("angle","Angular distribution",500,-4.,4.);
   TH1F *kinetic_energy   = new TH1F("kinetic_energy","Kinetic energy distribution of incoming particles",500,0,600);
   
   TH2F *r_vs_angle = new TH2F("r_vs_angle","r (cm) vs angle (radians)",600,0.,600., 600, -600., 600.);

   
   for (Int_t i = 0; i < entries; i++) 
   {
     PSPET->GetEntry(i);
     distance = TMath::Sqrt((X_second-X_first)*(X_second-X_first) + 
     			    (Y_second-Y_first)*(Y_second-Y_first) + 
     			    (Z_second-Z_first)*(Z_second-Z_first));
     cout << "Coordinates" << "  " << Z_first << " " << Z_second << endl;
     //cout << "Coordinates" << " = " << X_second << " " << Y_second << " " << Z_second << endl;
     r->Fill(distance);
     // angle->Fill(Angle);
     // kinetic_energy->Fill(KineticEne);
     // r_vs_angle->Fill(distance,KineticEne);
     
     //cout << "K.E. = " << KineticEne << endl;
     //cout << "Theta = " << Angle << endl;
     
   
   }
   
   // now the looop through all the entries is finished  
  gStyle->SetOptStat(0);

  // Create a Canvas where to plot the histogram created
  TCanvas *C1 = new TCanvas ("C1","Histograms", 800, 600);
  C1->Divide(2,2);
  C1->cd(1);
  r->Draw(); // Draw the histogram
  
  C1->cd(2);
  angle->Draw();
  
  C1->cd(3);
  kinetic_energy->Draw();
  
  C1->cd(4);
  r_vs_angle->Draw("COLZ");
  
  // Create a picture (just click on it in order to see it (or download it if
  // you want to keep it)
  C1->Print("Z_picture.jpeg");

}

   void SetLeafAddress(TTree* ntuple, const char* name, void* address)
  {
  TLeaf* leaf = ntuple->FindLeaf(name);
    
  if (!leaf)
  {
    std::cerr << "Error in <SetLeafAddress>: unknown leaf --> " << name
     << std::endl;

    return;
  }

  leaf->SetAddress(address);
  }
