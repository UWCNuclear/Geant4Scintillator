#ifndef PSPETScintillatorHit_h
#define PSPETScintillatorHit_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"
#include "G4Threading.hh"

/// Scintillator hit class
///
/// It defines data members to store the the energy deposit and track lengths
/// of charged particles in a selected volume:
/// - fEdep, fTrackLength

class PSPETScintillatorHit : public G4VHit
{
  public:
    PSPETScintillatorHit();
    PSPETScintillatorHit(const PSPETScintillatorHit&);
    virtual ~PSPETScintillatorHit();

    // operators
    const PSPETScintillatorHit& operator=(const PSPETScintillatorHit&);
    G4int operator==(const PSPETScintillatorHit&) const;

    inline void* operator new(size_t);
    inline void  operator delete(void*);

    // methods from base class
    virtual void Draw() {}
    virtual void Print();

    // methods to handle data
    void Add(G4double de, G4double dl, G4int nC, G4int nP);

    // get methods
    G4double GetEdep() const;
    G4double GetTrackLength() const;
    G4int GetNbOfCompton() const;
    G4int GetNbOfPhotoelectric() const;
    G4double GetXpos() const;
    G4double GetYpos() const;
    G4double GetZpos() const;
    G4double GetDistance() const;
      
  private:
    G4double fEdep;        ///< Energy deposit in the sensitive volume
    G4double fTrackLength; ///< Track length in the  sensitive volume
    G4int fNbOfCompton;
    G4int fNbOfPhotoelectric;
    G4double fXpos;
    G4double fYpos;
    G4double fZpos;
    G4double fDistance;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

using PSPETScintillatorHitsCollection = G4THitsCollection<PSPETScintillatorHit>;

extern G4ThreadLocal G4Allocator<PSPETScintillatorHit>*
 PSPETScintillatorHitAllocator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

inline void* PSPETScintillatorHit::operator new(size_t)
{
  if (!PSPETScintillatorHitAllocator)
  {
    PSPETScintillatorHitAllocator = new G4Allocator<PSPETScintillatorHit>;
  }
  
  void *hit;
  hit = (void *) PSPETScintillatorHitAllocator->MallocSingle();
  return hit;
}

inline void PSPETScintillatorHit::operator delete(void *hit)
{
  if (!PSPETScintillatorHitAllocator)
   PSPETScintillatorHitAllocator = new G4Allocator<PSPETScintillatorHit>;
  
  PSPETScintillatorHitAllocator->FreeSingle((PSPETScintillatorHit*) hit);
}

inline void PSPETScintillatorHit::Add(
  G4double de, G4double dl, G4int nC, G4int nP)
{
  fEdep += de; 
  fTrackLength += dl;
  fNbOfCompton += nC;
  fNbOfPhotoelectric += nP;
}

inline G4double PSPETScintillatorHit::GetEdep() const
{ 
  return fEdep; 
}

inline G4double PSPETScintillatorHit::GetTrackLength() const
{ 
  return fTrackLength; 
}

inline G4int PSPETScintillatorHit::GetNbOfCompton() const
{ 
  return fNbOfCompton; 
}

inline G4int PSPETScintillatorHit::GetNbOfPhotoelectric() const
{ 
  return fNbOfPhotoelectric; 
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
