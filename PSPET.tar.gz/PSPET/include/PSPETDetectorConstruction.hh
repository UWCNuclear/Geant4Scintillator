#ifndef PSPETDetectorConstruction_h
#define PSPETDetectorConstruction_h 1

#include "G4VUserDetectorConstruction.hh"
#include "globals.hh"

class G4VPhysicalVolume;
class G4UserLimits;
class G4GlobalMagFieldMessenger;

/// Detector construction class to define materials and geometry.
/// The scintillator is a box made of a liquid water.
///
/// Four parameters define the geometry of the scintillator:
///
/// - the size along X and Y axis,
/// - the thickness - size along Z axes,
/// - the material,
///
/// In ConstructSDandField() sensitive detectors of PSPETScintillatorSD type
/// are created and associated with the scintillator volumes.
/// In addition a transverse uniform magnetic field is defined 
/// via G4GlobalMagFieldMessenger class.

class PSPETDetectorConstruction : public G4VUserDetectorConstruction
{
  public:
    PSPETDetectorConstruction();
    virtual ~PSPETDetectorConstruction();

  public:
    virtual G4VPhysicalVolume* Construct();
    virtual void ConstructSDandField();
     
  private:
    // methods
    //
    void DefineMaterials();
    G4VPhysicalVolume* DefineVolumes();
  
    // data members
    //
    static G4ThreadLocal G4GlobalMagFieldMessenger*  fMagFieldMessenger; 
                                      // magnetic field messenger

    G4bool  fCheckOverlaps; // option to activate checking of volumes overlaps
    G4UserLimits* fStepLimit;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif

