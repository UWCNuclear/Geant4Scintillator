#ifndef PSPETActionInitialization_h
#define PSPETActionInitialization_h 1

#include "G4VUserActionInitialization.hh"

/// Action initialization class.
///

class PSPETActionInitialization : public G4VUserActionInitialization
{
  public:
    PSPETActionInitialization();
    virtual ~PSPETActionInitialization();

    virtual void BuildForMaster() const;
    virtual void Build() const;
};

#endif

    
