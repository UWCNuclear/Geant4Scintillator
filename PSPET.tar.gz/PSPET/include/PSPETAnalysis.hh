#ifndef PSPETAnalysis_h
#define PSPETAnalysis_h 1

#include "g4root.hh"

#endif
