#ifndef PSPETDATA_HH
#define PSPETDATA_HH

#include "G4Threading.hh"
#include "G4ThreeVector.hh"

namespace PSPET
{
  extern G4int nbOneCompton;
  extern G4int nbTwoMoreCompton;
  extern G4int nbThreeMoreCompton;
  extern G4int nbPhotoelectric;

  extern G4int detectedQEPET;
  extern G4int detectedPET;
  
  extern G4int nbComptonDetected;
  extern G4double EdepFirstCompton;
  extern G4double EdepSecondCompton;
  extern G4double EdepThirdCompton;
  extern G4double thetaFirstCompton; 
  extern G4double xFirstCompton;
  extern G4double yFirstCompton;
  extern G4double zFirstCompton;
  extern G4double xSecondCompton;
  extern G4double ySecondCompton;
  extern G4double zSecondCompton;
  extern G4double xThirdCompton;
  extern G4double yThirdCompton;
  extern G4double zThirdCompton;
}

#endif
