#ifndef PSPETEventAction_h
#define PSPETEventAction_h 1

#include "G4UserEventAction.hh"

#include "PSPETScintillatorHit.hh"

#include "globals.hh"

/// Event action class
///
/// EndOfEventAction(), it prints the accumulated quantities of the energy 
/// deposit and track lengths of charged particles in scintillator and Gap layers 
/// stored in the hits collections.

class PSPETEventAction : public G4UserEventAction
{
public:
  PSPETEventAction();
  virtual ~PSPETEventAction();

  virtual void  BeginOfEventAction(const G4Event* event);
  virtual void    EndOfEventAction(const G4Event* event);
    
private:
  // methods
  PSPETScintillatorHitsCollection*
   GetHitsCollection(G4int hcID, const G4Event* event) const;
  void PrintEventStatistics(
    G4double scintillator1Edep)
    const;
  
  // data members                   
  G4int fScintillator1HCID;
  //G4int fScintillator2HCID;
  //G4int fScintillator3HCID;
};
                     
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif

    
