#include "PSPETData.hh"

#include "PSPETScintillatorSD.hh"
#include "G4HCofThisEvent.hh"
#include "G4Step.hh"
#include "G4VProcess.hh"
#include "G4ThreeVector.hh"
#include "G4SDManager.hh"
#include "G4ios.hh"

#include "G4TrackingManager.hh"
#include "G4Electron.hh"
#include <G4UnitsTable.hh>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETScintillatorSD::PSPETScintillatorSD(
                            const G4String& name,
                            const G4String& hitsCollectionName,
                            G4int nbCells)
 : G4VSensitiveDetector(name),
   fHitsCollection(nullptr),
   fNbCells(nbCells)
{
  collectionName.insert(hitsCollectionName);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETScintillatorSD::~PSPETScintillatorSD()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETScintillatorSD::Initialize(G4HCofThisEvent* hce)
{
  // Create hits collection
  fHitsCollection = new PSPETScintillatorHitsCollection(SensitiveDetectorName,
   collectionName[0]);

  // Add this collection in hce
  G4int hcID = G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]);
  hce->AddHitsCollection(hcID, fHitsCollection);

  // Create hits
  // fNbCells for cells + one more for total sums
  for (G4int i = 0; i < fNbCells + 1; i++)
  {
    fHitsCollection->insert(new PSPETScintillatorHit());
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4bool PSPETScintillatorSD::ProcessHits(G4Step* step, G4TouchableHistory*)
{
  // Energy deposit
  G4double edep = step->GetTotalEnergyDeposit();
  
  //Calculating the energy lost after Compton scattering
  G4double Elost =
   step->GetPreStepPoint()->GetKineticEnergy()
   - step->GetPostStepPoint()->GetKineticEnergy();
     
  G4ThreeVector p2 = step->GetPostStepPoint()->GetPosition();

  // Declaring variables
  G4double stepLength = 0.;
  G4int nbOfCompton = 0;
  G4int nbOfPhotoelectric = 0;

  const G4VProcess* postProcessDefinedStep =
   step->GetPostStepPoint()->GetProcessDefinedStep();

  // Collects data if the particle is a gamma-ray and the process 
  // is either Compton scattering or photoelectric absorption.
  if (step->GetTrack()->GetTrackID() == 1
      && (postProcessDefinedStep->GetProcessName() == "compt"
          || postProcessDefinedStep->GetProcessName() == "phot"))
  {
    stepLength = step->GetStepLength();
    
     // Counting the number of photoelectric absorption
    if (postProcessDefinedStep->GetProcessName() == "phot") nbOfPhotoelectric++;
    
    // Counting  the number of Compton scattering    
    if (postProcessDefinedStep->GetProcessName() == "compt") nbOfCompton++;    
    
    // G4cout << "nbOfCompton" << " = " << nbOfCompton << G4endl;
    
    // Collecting information after the first Compton scattering
    if (PSPET::nbComptonDetected == 0
        && postProcessDefinedStep->GetProcessName() == "compt")
    {
      PSPET::EdepFirstCompton = Elost / keV;

      G4double E = step->GetTrack()->GetKineticEnergy();
      G4double Eoutcoming = E/keV;
        
      //Determine polar angle in radians
      PSPET::thetaFirstCompton = std::acos(2 - 511 / Eoutcoming);

      PSPET::xFirstCompton = p2.x();
      PSPET::yFirstCompton = p2.y();
      PSPET::zFirstCompton = p2.z();       
    }
      
    // Collecting information after the second Compton scattering
    if (PSPET::nbComptonDetected == 1)
    {
      
      PSPET::EdepSecondCompton = Elost / keV;

      //Recording the coordinates after second Compton scattering
      PSPET::xSecondCompton = p2.x();
      PSPET::ySecondCompton = p2.y();
      PSPET::zSecondCompton = p2.z();
    }

    /// Collecting information after the third Compton scattering
    if (PSPET::nbComptonDetected == 2)
    {
       //Recording the coordinates after second Compton scattering
      PSPET::EdepThirdCompton = Elost / keV;

       //Recording the coordinates after third Compton scattering
      PSPET::xThirdCompton = p2.x();
      PSPET::yThirdCompton = p2.y();
      PSPET::zThirdCompton = p2.z();
    }

    PSPET::nbComptonDetected++;
  }

  if (edep == 0. && stepLength == 0.) return false;

  const G4VTouchable* touchable = (step->GetPreStepPoint()->GetTouchable());

  // Get scintillator ID
  G4int scintillatorID = touchable->GetReplicaNumber(1);

  // Get hit accounting data for this cell
  PSPETScintillatorHit* hit = (*fHitsCollection)[scintillatorID];

  if (!hit)
  {
    G4ExceptionDescription msg;
    msg << "Cannot access hit " << scintillatorID;
    G4Exception("PSPETScintillatorSD::ProcessHits()",
      "MyCode0004", FatalException, msg);
  }

  // Get hit for total accounting
  PSPETScintillatorHit* hitTotal =
   (*fHitsCollection)[fHitsCollection->entries() - 1];

  // Add values
  hit->Add(edep, stepLength, nbOfCompton, nbOfPhotoelectric);
  hitTotal->Add(edep, stepLength, nbOfCompton, nbOfPhotoelectric);

  return true;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETScintillatorSD::EndOfEvent(G4HCofThisEvent*)
{
  if (verboseLevel > 1)
  {
    G4int nbHits = fHitsCollection->entries();

    G4cout
      << G4endl
      << "--------> In this event there are " << nbHits
      << " hits in the scintillator: " << G4endl;
    for (G4int i = 0; i < nbHits; i++) (*fHitsCollection)[i]->Print();
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
