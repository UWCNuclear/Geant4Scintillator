#include "PSPETData.hh"

//Declaring global variables.
G4int PSPET::nbOneCompton = 0;
G4int PSPET::nbTwoMoreCompton = 0;
G4int PSPET::nbThreeMoreCompton = 0;
G4int PSPET::nbPhotoelectric = 0;


G4int PSPET::detectedQEPET = 0;
G4int PSPET::detectedPET = 0;

G4int PSPET::nbComptonDetected = 0;
G4double PSPET::EdepFirstCompton = 0.;
G4double PSPET::EdepSecondCompton = 0.;
G4double PSPET::EdepThirdCompton = 0.;
G4double PSPET::thetaFirstCompton = 0.;
G4double PSPET::xFirstCompton = 0.;
G4double PSPET::yFirstCompton = 0.;
G4double PSPET::zFirstCompton = 0.;
G4double PSPET::xSecondCompton = 0.;
G4double PSPET::ySecondCompton = 0.;
G4double PSPET::zSecondCompton = 0.;
G4double PSPET::xThirdCompton = 0.;
G4double PSPET::yThirdCompton = 0.;
G4double PSPET::zThirdCompton = 0.;
