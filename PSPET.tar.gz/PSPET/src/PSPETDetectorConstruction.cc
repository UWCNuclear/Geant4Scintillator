#include "PSPETDetectorConstruction.hh"
#include "PSPETScintillatorSD.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"

#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4GlobalMagFieldMessenger.hh"
#include "G4AutoDelete.hh"

#include "G4SDManager.hh"

#include "G4UserLimits.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#define scintillator1

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4ThreadLocal
G4GlobalMagFieldMessenger*
 PSPETDetectorConstruction::fMagFieldMessenger = 0;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETDetectorConstruction::PSPETDetectorConstruction()
 : G4VUserDetectorConstruction(),
   fCheckOverlaps(true),
   fStepLimit(NULL)
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETDetectorConstruction::~PSPETDetectorConstruction()
{
  delete fStepLimit;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* PSPETDetectorConstruction::Construct()
{
  // Define materials
  DefineMaterials();

  // Define volumes
  return DefineVolumes();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETDetectorConstruction::DefineMaterials()
{
  // Define air using NIST definition
  G4NistManager* nist = G4NistManager::Instance();

  nist->FindOrBuildMaterial("G4_AIR");
  
  // Chemical elements needed for the definion of the scintillator material
  G4Element* carbon = new G4Element("Carbon", "C", 6., 12.011*g/mole);
  G4Element* hydrogen = new G4Element("Hydrogen", "H", 1., 1.00794*g/mole);

  // Material scintillators 1: EJ-200 of Eljen Technology
  G4Material* dopedEJ200_S1 = new G4Material("EJ200_scintillator1", 1.023*g/cm3,
                                             2);
  
  dopedEJ200_S1->AddElement(carbon, .915);
  dopedEJ200_S1->AddElement(hydrogen, .085);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* PSPETDetectorConstruction::DefineVolumes()
{
  // World volume and material
  G4double worldEdgeSize = 100.*m;

  G4Material* worldMaterial = G4Material::GetMaterial("G4_AIR");

  G4double maxStep = .001*mm;
  fStepLimit = new G4UserLimits(maxStep);

  // World

  // Solid
  G4VSolid* world_solid
    = new G4Box("World",           // its name
                worldEdgeSize/2, worldEdgeSize/2, worldEdgeSize/2); // its size

  // Logical volume
  G4LogicalVolume* world_log
    = new G4LogicalVolume(
                 world_solid,           // its solid
                 worldMaterial,  // its material
                 "World");         // its name

  // Physical volume
  G4VPhysicalVolume* world_phys
    = new G4PVPlacement(
                 0,                // no rotation
                 G4ThreeVector(0., 0., 0.),  // coordinates
                 world_log,          // its logical volume
                 "World_Phys",          // its name
                 0,                // its mother  volume
                 false,            // no boolean operation
                 0,                // copy number
                 fCheckOverlaps);  // checking overlaps

  // Visualization attributes
  world_log->SetVisAttributes(G4VisAttributes::GetInvisible());

  // The scintillators all have same dimensions
  G4double scintillatorSizeX  = 20.*m;
  G4double scintillatorSizeY  = 20.*m;
  G4double scintillatorThickness = 20.*m;
  
  // Solid volume of the scintillators
  G4VSolid* scintillator_solid
    = new G4Box("Scintillator1_Solid",     // its name
                 scintillatorSizeX/2,
                 scintillatorSizeY/2,
                 scintillatorThickness/2); // its size
  
  // Scintillator 1
  G4Material* scintillator1Material =
   G4Material::GetMaterial("EJ200_scintillator1");

  // Logical volume
  G4LogicalVolume* scintillator1_log
    = new G4LogicalVolume(
                 scintillator_solid,     // its solid
                 scintillator1Material,  // its material
                 "Scintillator1_Log");   // its name

  scintillator1_log->SetUserLimits(fStepLimit);

  G4VisAttributes* scintillator1VisAtt =
  new G4VisAttributes(G4Colour(1., 1., 1.));
  scintillator1VisAtt->SetVisibility(true);
  scintillator1_log->SetVisAttributes(scintillator1VisAtt);

  // Physical volume
  new G4PVPlacement(
                 0,                // no rotation
                 // Position (x, y, z) such that the entrance of the detector is 
                 // 40 cm away from the source
                 G4ThreeVector(0., 0., 40.*cm + scintillatorThickness / 2.),  
                 scintillator1_log,          // its logical volume
                 "Scintillator1_Phys",    // its name
                 world_log,          // its mother volume
                 false,            // no boolean operation
                 0,                // copy number
                 fCheckOverlaps);  // checking overlaps

  return world_phys;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETDetectorConstruction::ConstructSDandField()
{
  // Sensitive detectors

  PSPETScintillatorSD* scintillator1SD =
   new PSPETScintillatorSD("Scintillator1SD", "Scintillator1HitsCollection", 1);
  G4SDManager::GetSDMpointer()->AddNewDetector(scintillator1SD);
  SetSensitiveDetector("Scintillator1_Log", scintillator1SD);

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
