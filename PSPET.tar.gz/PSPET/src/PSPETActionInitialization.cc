#include "PSPETActionInitialization.hh"
#include "PSPETPrimaryGeneratorAction.hh"
#include "PSPETRunAction.hh"
#include "PSPETEventAction.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETActionInitialization::PSPETActionInitialization()
 : G4VUserActionInitialization()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETActionInitialization::~PSPETActionInitialization()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETActionInitialization::BuildForMaster() const
{
  SetUserAction(new PSPETRunAction);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETActionInitialization::Build() const
{
  SetUserAction(new PSPETPrimaryGeneratorAction);
  SetUserAction(new PSPETRunAction);
  SetUserAction(new PSPETEventAction);
}  

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
