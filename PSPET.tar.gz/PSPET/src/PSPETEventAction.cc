#include "PSPETData.hh"

#include "PSPETEventAction.hh"
#include "PSPETScintillatorSD.hh"
#include "PSPETScintillatorHit.hh"
#include "PSPETAnalysis.hh"

#include "G4RunManager.hh"
#include "G4Event.hh"
#include "G4SDManager.hh"
#include "G4HCofThisEvent.hh"
#include "G4UnitsTable.hh"

#include "Randomize.hh"
#include <iomanip>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETEventAction::PSPETEventAction()
 : G4UserEventAction(),
   fScintillator1HCID(-1)
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETEventAction::~PSPETEventAction()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETScintillatorHitsCollection* 
PSPETEventAction::GetHitsCollection(G4int hcID, const G4Event* event) const
{
  PSPETScintillatorHitsCollection* hitsCollection 
    = static_cast<PSPETScintillatorHitsCollection*>
    (event->GetHCofThisEvent()->GetHC(hcID));
  
  if (!hitsCollection)
  {
    G4ExceptionDescription msg;
    msg << "Cannot access hitsCollection ID " << hcID; 
    G4Exception("PSPETEventAction::GetHitsCollection()",
      "MyCode0003", FatalException, msg);
  }         

  return hitsCollection;
}    

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETEventAction::PrintEventStatistics(
  G4double scintillator1Edep) const
{
  // print event statistics
  G4cout << "Scintillator 1: Energy deposited = " 
     << std::setprecision(3) << G4BestUnit(scintillator1Edep, "Energy")
     << G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETEventAction::BeginOfEventAction(const G4Event*)
{
  //Declaring variables
  PSPET::nbComptonDetected = 0;
  PSPET::thetaFirstCompton = 0.;
  PSPET::EdepFirstCompton = 0.;
  PSPET::EdepSecondCompton = 0.;
  PSPET::EdepThirdCompton = 0.;
  PSPET::xFirstCompton = 0.;
  PSPET::yFirstCompton = 0.;
  PSPET::zFirstCompton = 0.;
  PSPET::xSecondCompton = 0.;
  PSPET::ySecondCompton = 0.;
  PSPET::zSecondCompton = 0.;
  PSPET::xThirdCompton = 0.;
  PSPET::yThirdCompton = 0.;
  PSPET::zThirdCompton = 0.;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETEventAction::EndOfEventAction(const G4Event* event)
{  
  // Get hits collections IDs (only once)
  if (fScintillator1HCID == -1)
  {
    fScintillator1HCID 
      = G4SDManager::GetSDMpointer()
      ->GetCollectionID("Scintillator1HitsCollection");   
  }
 
  // Get hits collections
  PSPETScintillatorHitsCollection* scintillator1HC =
   GetHitsCollection(fScintillator1HCID, event);

  // Get hit with total values
  PSPETScintillatorHit* scintillator1Hit =
   (*scintillator1HC)[scintillator1HC->entries()-1];
 
  // Print per event (modulo n)
  G4int eventID = event->GetEventID();
  G4int printModulo = G4RunManager::GetRunManager()->GetPrintProgress();

  // Counter for different types of interactions

  if (scintillator1Hit->GetNbOfCompton() == 1) PSPET::nbOneCompton++;
  if (scintillator1Hit->GetNbOfCompton() == 2) PSPET::nbTwoMoreCompton++;
  if (scintillator1Hit->GetNbOfCompton() == 3) PSPET::nbThreeMoreCompton++;
  if (scintillator1Hit->GetNbOfPhotoelectric() > 0) PSPET::nbPhotoelectric++;

  // To count the number of QE-PET events
  if (scintillator1Hit->GetNbOfCompton() == 1) PSPET::detectedQEPET++;

  // To count the number of conventional PET events
  if ((scintillator1Hit->GetNbOfPhotoelectric() == 1
   || scintillator1Hit->GetNbOfCompton() == 1)
   ) PSPET::detectedPET++;

  if ((printModulo > 0) && (eventID % printModulo == 0))
  {
    PrintEventStatistics(scintillator1Hit->GetEdep());
  }  
  
  // Fill histograms, ntuple
  // get analysis manager
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
 
  // // fill histograms
  // analysisManager->FillH1(1, scintillator1Hit->GetNbOfCompton());
  G4double sumEdep = PSPET::EdepFirstCompton + PSPET::EdepSecondCompton;
                     // + PSPET::EdepThirdCompton;

  if (sumEdep > 511.)
   G4cout << "WARNING: Edep > 511 keV" << G4endl;

  //Filling the Ntuples with recorded information
  analysisManager->FillNtupleDColumn(0, PSPET::EdepFirstCompton);
  analysisManager->FillNtupleDColumn(1, PSPET::thetaFirstCompton);
  analysisManager->FillNtupleDColumn(2, PSPET::EdepSecondCompton);
  analysisManager->FillNtupleDColumn(3, PSPET::EdepThirdCompton);
  analysisManager->FillNtupleDColumn(4, PSPET::xFirstCompton);
  analysisManager->FillNtupleDColumn(5, PSPET::yFirstCompton);
  analysisManager->FillNtupleDColumn(6, PSPET::zFirstCompton);
  analysisManager->FillNtupleDColumn(7, PSPET::xSecondCompton);
  analysisManager->FillNtupleDColumn(8, PSPET::ySecondCompton);
  analysisManager->FillNtupleDColumn(9, PSPET::zSecondCompton);
  analysisManager->FillNtupleDColumn(10, PSPET::xThirdCompton);
  analysisManager->FillNtupleDColumn(11, PSPET::yThirdCompton);
  analysisManager->FillNtupleDColumn(12, PSPET::zThirdCompton);
  analysisManager->FillNtupleDColumn(13, PSPET::nbComptonDetected);
  analysisManager->AddNtupleRow();
}  

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
