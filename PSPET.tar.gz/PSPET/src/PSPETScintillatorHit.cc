#include "PSPETScintillatorHit.hh"
#include "G4UnitsTable.hh"
#include "G4VVisManager.hh"
#include "G4Circle.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"

#include <iomanip>

G4ThreadLocal G4Allocator<PSPETScintillatorHit>* PSPETScintillatorHitAllocator = 0;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETScintillatorHit::PSPETScintillatorHit()
 : G4VHit(),
   fEdep(0.),
   fTrackLength(0.),
   fNbOfCompton(0),
   fNbOfPhotoelectric(0),
   fDistance(0)
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETScintillatorHit::~PSPETScintillatorHit()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETScintillatorHit::PSPETScintillatorHit(const PSPETScintillatorHit& right)
  : G4VHit()
{
  fEdep = right.fEdep;
  fTrackLength = right.fTrackLength;
  fNbOfCompton = right.fNbOfCompton;
  fNbOfPhotoelectric = right.fNbOfPhotoelectric;
  fDistance = right.fDistance;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

const PSPETScintillatorHit&
 PSPETScintillatorHit::operator=(const PSPETScintillatorHit& right)
{
  fEdep = right.fEdep;
  fTrackLength = right.fTrackLength;
  fNbOfCompton = right.fNbOfCompton;
  fNbOfPhotoelectric = right.fNbOfPhotoelectric;
  fDistance = right.fDistance;

  return *this;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4int PSPETScintillatorHit::operator==(const PSPETScintillatorHit& right) const
{
  return (this == &right) ? 1 : 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETScintillatorHit::Print()
{
  G4cout
     << "Edep: " 
     << std::setw(7) << G4BestUnit(fEdep, "Energy")
     << G4endl;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
