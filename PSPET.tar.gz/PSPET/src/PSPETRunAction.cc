#include "PSPETData.hh"

#include "PSPETRunAction.hh"
#include "PSPETAnalysis.hh"

#include "G4Run.hh"
#include "G4RunManager.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETRunAction::PSPETRunAction()
 : G4UserRunAction()
{
  // set printing event number per each event
  G4RunManager::GetRunManager()->SetPrintProgress(0);

  // Create analysis manager
  // The choice of analysis technology is done via selection of a namespace
  // in PSPETAnalysis.hh
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
  G4cout << "Using " << analysisManager->GetType() << G4endl;

  analysisManager->SetVerboseLevel(0);
  analysisManager->SetNtupleMerging(true);

  // Book histograms, ntuple

  // Creating histograms
  analysisManager
  ->CreateH1("Number of Compton scatterings","track length in material; z(mm)",
   500, 0., 0.5*m);

  // Creating Ntuples to store the recorded information
  //
  analysisManager->CreateNtuple("PSPET", "Edep spatial distribution");

  analysisManager->CreateNtupleDColumn("Edep1");
  analysisManager->CreateNtupleDColumn("theta1");
  analysisManager->CreateNtupleDColumn("Edep2");
  analysisManager->CreateNtupleDColumn("Edep3");
  analysisManager->CreateNtupleDColumn("X1");
  analysisManager->CreateNtupleDColumn("Y1");
  analysisManager->CreateNtupleDColumn("Z1");
  analysisManager->CreateNtupleDColumn("X2");
  analysisManager->CreateNtupleDColumn("Y2");
  analysisManager->CreateNtupleDColumn("Z2");
  analysisManager->CreateNtupleDColumn("X3");
  analysisManager->CreateNtupleDColumn("Y3");
  analysisManager->CreateNtupleDColumn("Z3");
  analysisManager->CreateNtupleDColumn("nbOfCompton");
  
  analysisManager->FinishNtuple();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PSPETRunAction::~PSPETRunAction()
{
  delete G4AnalysisManager::Instance();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETRunAction::BeginOfRunAction(const G4Run*)
{
  // Get analysis manager
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();

  // Open an output file
  //
  G4String fileName = "PSPET";
  analysisManager->OpenFile(fileName);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void PSPETRunAction::EndOfRunAction(const G4Run* run)
{
  // print histogram statistics
  //
  G4AnalysisManager* analysisManager = G4AnalysisManager::Instance();
   
  if(isMaster)
  {
      G4int nbOfEvents = run->GetNumberOfEvent();

      G4cout << " " << G4endl;
      G4cout << "End of the " << nbOfEvents << " events simulation" << G4endl;
      G4cout << " " << G4endl;
  }

  // save histograms & ntuple
  analysisManager->Write();
  analysisManager->CloseFile();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
