void SetLeafAddress(TTree* ntuple, const char* name, void* address);


void analysis()
{
  // Detector energy threshold in keV
  Double_t threshold = 20.;
  
  // Reading the input file
  TFile *file_input = TFile::Open("PSPET.root");
    
  // Reading the data (in TTree format)
  TTree *PSPET =(TTree *) file_input->Get("PSPET; 1");
    
  bool rowWise = true;
    
  TBranch* eventBranch = PSPET->FindBranch("row_wise_branch");
  
  if (! eventBranch) rowWise = false;
        
  //Setting up your variables that you want to read from the data
  double Edep1;
  double theta1;
  double Edep2;
  double Edep3;
  double X1;
  double Y1;
  double Z1;
  double X2;
  double Y2;
  double Z2;
  double X3;
  double Y3;
  double Z3;
  double distance;
  double depth;
  double nbOfCompton;
  //double nbOfPhotoelectric;
    
  // Connect these variables to the one in the TTree data
  if (!rowWise)
  {
    PSPET->SetBranchAddress("Edep1", &Edep1);
    PSPET->SetBranchAddress("theta1", &theta1);
    PSPET->SetBranchAddress("Edep2", &Edep2);
    PSPET->SetBranchAddress("Edep3", &Edep3);
    PSPET->SetBranchAddress("X1", &X1);
    PSPET->SetBranchAddress("Y1", &Y1);
    PSPET->SetBranchAddress("Z1", &Z1);
    PSPET->SetBranchAddress("X2", &X2);
    PSPET->SetBranchAddress("Y2", &Y2);
    PSPET->SetBranchAddress("Z2", &Z2);
    PSPET->SetBranchAddress("X3", &X3);
    PSPET->SetBranchAddress("Y3", &Y3);
    PSPET->SetBranchAddress("Z3", &Z3);
    PSPET->SetBranchAddress("nbOfCompton", &nbOfCompton);
    //PSPET->SetBranchAddress("nbOfPhotoelectric", &nbOfPhotoelectric);
  }
  
  else
  {
    SetLeafAddress(PSPET, "Edep1", &Edep1);
    SetLeafAddress(PSPET, "theta1", &theta1);
    SetLeafAddress(PSPET, "Edep2", &Edep2);
    SetLeafAddress(PSPET, "Edep2", &Edep3);
    SetLeafAddress(PSPET, "X1", &X1);
    SetLeafAddress(PSPET, "Y1", &Y1);
    SetLeafAddress(PSPET, "Z1", &Z1);
    SetLeafAddress(PSPET, "X2", &X2);
    SetLeafAddress(PSPET, "Y2", &Y2);
    SetLeafAddress(PSPET, "Z2", &Z2);
    SetLeafAddress(PSPET, "X3", &X2);
    SetLeafAddress(PSPET, "Y3", &Y2);
    SetLeafAddress(PSPET, "Z3", &Z3);
    SetLeafAddress(PSPET, "nbOfCompton", &nbOfCompton);
    //SetLeafAddress(PSPET, "nbOfPhotoelectric", &nbOfPhotoelectric);
  }
    
  int entries = PSPET->GetEntries();
    
 // Creating 1D and 2D histograms 
  TH1F *r   = 
  new TH1F("r", "Distance between the first and the second Compton scattering",
           300, 0, 50);
  
  TH1F *depthCompton1 = new TH1F("depthCompton1", 
                                 "Depth of the first Compton scattering", 
                                 120, 0., 60.);
  
  TH1F *depthCompton2 = new TH1F("depthCompton2", 
                                 "Depth of the second Compton scattering", 
                                 120, 0., 60.);
                                
  TH1F *depthCompton3 = new TH1F("depthCompton3", 
                                 "Depth of the third Compton scattering", 
                                 120, 0., 60.);

  TH1F *theta_Compton1 = 
   new TH1F("theta_Compton1",
            "Polar angle distribution (first Compton scattering)",
            500, 0., 180.);

  TH1F *E_Compton1 =
   new TH1F("E_Compton1",
            "Energy distribution - 1st Compton scattering",
            500, 50., 400);
            
   TH1F *E_Compton2 =
   new TH1F("E_Compton2",
            "Energy distribution - 2nd Compton scattering",
            500, 50., 400);
   
   TH1F *E_Compton3 =
   new TH1F("E_Compton3",
            "Energy distribution - 3rd Compton scattering",
            500, 50., 400);

  TH2F *E_Compton2_vs_E_Compton1 =
   new TH2F("E_Compton2_vs_E_Compton1",
            "Edep second Compton vs Edep first Compton",
            200, 0., 350., 200, 0., 350.);
            
  TH2F *E_Compton3_vs_E_Compton2 =
   new TH2F("E_Compton3_vs_E_Compton2",
            "Edep second Compton vs Edep third Compton",
            200, 0., 350., 200, 0., 350.);
            
  TH2F *E_Compton3_vs_E_Compton1 =
   new TH2F("E_Compton3_vs_Compton1",
            "Edep first Compton vs Edep third Compton",
            200, 0., 350., 200, 0., 350.);
           
   TH2F *E_Compton3_vs_E_Compton2_E_Compton1_180keV_300keV  =
   new TH2F("E_Compton3_vs_E_Compton2_E_Compton1_180keV_300keV",
            "Edep second Compton vs Edep third Compton if Edep first Compton >180keV && < 300keV",
            200, 0., 350., 200, 0., 350.);

   TH2F *distribution =
   new TH2F("distribution",
            "Projection of the points of interaction of the second Compton scatterings onto (x, y)",
            200, -100., 100., 200, -100., 100.);
            
   TH2F *distance_vs_theta =
   new TH2F("distance_vs_theta",
            "Angular distribution as a function of distance between interactions",
            200, 0., 200., 200, 0., 100.);
            
   TH2F *E_Compton1_vs_theta =
   new TH2F("E_Compton1_vs_theta",
            "Angular distribution as a function of energy deposited after first interaction",
            200, 0., 200., 200, 0., 400.);
            
   TH2F *E_Compton2_vs_theta =
   new TH2F("E_Compton2_vs_theta",
            "Angular distribution as a function of energy deposited after second interactions",
            200, 0., 200., 200, 0., 400.);
            
   TH2F *E_Compton1_vs_distance =
   new TH2F("E_Compton1_vs_distance",
            "Distance between 1st & 2nd Compton interaction as a function of energy deposited after first interactions",
            200, 0., 200., 200, 0., 400.);
            
   TH2F *E_Compton3_vs_theta =
   new TH2F("E_Compton3_vs_theta",
            "Angular distribution as a function of energy deposited after third interactions",
            200, 0., 200., 200, 0., 400.);
            
   TH2F *ratioEdep2Edep3_vs_Edep2 =
   new TH2F("ratioEdep2Edep3_vs_Edep2",
            "Ratio of E_Compton2 and E_Compton3 vs E_Compton2",
            200, 0., 511., 200, 0., 511.);

   TH1F *distrCompton =
   new TH1F("distrCompton",
            "Distribution of the numbre of Compton interactions per gamma",
            40, 0, 40);

  // loop through all the entries in the data file
  for (int i = 0; i < entries; i++)
  {
    // Read the single entry inside the data file (Now all the variables are
    // linked to the values at this entry)
    PSPET->GetEntry(i);

    // Need to check wether the gamma has lost energy (at least) twice in the
    // detector energy threshold
    if (Edep1 > threshold && Edep2 > threshold)
    {
      //Calculating the distance between the first and the second Compton interaction
      distance = TMath::Sqrt((X2 - X1) * (X2 - X1) + 
                             (Y2 - Y1) * (Y2 - Y1) + 
                             (Z2 - Z1) * (Z2 - Z1));
      //Filling information into the histograms
      r->Fill(distance/10.);

      depthCompton1->Fill(Z1/10. - 30.);
      depthCompton2->Fill(Z2/10. - 30.);
      
      distrCompton->Fill(nbOfCompton);
      
      theta_Compton1->Fill(theta1 * 180. / TMath::Pi());
      E_Compton1->Fill(Edep1);
      E_Compton2->Fill(Edep2);
      
      E_Compton2_vs_E_Compton1->Fill(Edep1, Edep2);
      
      distance_vs_theta->Fill(theta1 * 180. / TMath::Pi(), distance/10.);
      E_Compton1_vs_theta->Fill(theta1 * 180. / TMath::Pi(), Edep1);
      E_Compton2_vs_theta->Fill(theta1 * 180. / TMath::Pi(), Edep2);
      
      E_Compton1_vs_distance->Fill(distance/10, Edep1);
      
      //Appling energy threshold
      if (Edep3 > threshold)
      {
        depthCompton3->Fill(Z3/10. - 30.);
        E_Compton3->Fill(Edep3);
        E_Compton3_vs_E_Compton2->Fill(Edep2, Edep3);
        E_Compton3_vs_E_Compton1->Fill(Edep1, Edep3);
        E_Compton3_vs_theta->Fill(theta1 * 180. / TMath::Pi(), Edep3);
        ratioEdep2Edep3_vs_Edep2->Fill(Edep2, Edep3/Edep2, 1);
	
	    //Gating on the energy
        if (Edep1 > 180. && Edep1 < 300.)
           E_Compton3_vs_E_Compton2_E_Compton1_180keV_300keV->Fill(Edep2,Edep3);
      }
    }
  }

  // now the looop through all the entries is finished  
  // gStyle->SetOptStat(0);
  gStyle->SetOptStat(1001111);

  // Create a Canvas where to plot the histogram created
  TCanvas *C1 = new TCanvas ("C1","Histograms", 800, 600);
  C1->Divide(3, 2);
  
  C1->cd(1);
  E_Compton1->GetXaxis()->SetTitle("Energy Compton (keV)");
  E_Compton1->GetYaxis()->SetTitle("Count");
  E_Compton1->SetLineColor(kRed);
  E_Compton1->Draw();

  C1->cd(2);
  E_Compton2->GetXaxis()->SetTitle("Energy Compton (keV)");
  E_Compton2->GetYaxis()->SetTitle("Count");
  E_Compton2->SetLineColor(kGreen);
  E_Compton2->Draw();
    
  C1->cd(3);
  E_Compton3->GetXaxis()->SetTitle("Energy Compton (keV)");
  E_Compton3->GetYaxis()->SetTitle("Count");
  E_Compton3->SetLineColor(kBlue);
  E_Compton3->Draw();
      
  C1->cd(4);
  depthCompton1->GetXaxis()->SetTitle("Depth (cm)");
  depthCompton1->GetYaxis()->SetTitle("Count");
  depthCompton1->SetLineColor(kRed);
  depthCompton1->Draw();

  C1->cd(5);
  depthCompton2->GetXaxis()->SetTitle("Depth (cm)");
  depthCompton2->GetYaxis()->SetTitle("Count");
  depthCompton2->SetLineColor(kGreen);
  depthCompton2->Draw();

  C1->cd(6);
  depthCompton3->GetXaxis()->SetTitle("Depth (cm)");
  depthCompton3->GetYaxis()->SetTitle("Count");
  depthCompton3->SetLineColor(kBlue);
  depthCompton3->Draw();

  TCanvas *C2 = new TCanvas ("C2","Histograms", 800, 600);
  C2->Divide(2, 1);

  C2->cd(1);
  r->GetXaxis()->SetTitle("Distance (cm)");
  r->GetYaxis()->SetTitle("Count");
  r->SetLineColor(kBlack);
  r->Draw();

  C2->cd(2);
  distrCompton->GetXaxis()->SetTitle(
    "Number of Compton scattering / annihilation gamma (cm)");
  distrCompton->GetYaxis()->SetTitle("Count");
  distrCompton->SetLineColor(kBlack);
  distrCompton->Draw();


      
      // C4->cd();
      // distrCompton->Draw();
      
      // C5->cd();
      // theta_Compton1->Draw();
      

      
      // C7->cd();
      // E_Compton2->Draw();
      
      // C8->cd();
      // E_Compton2_vs_E_Compton1->Draw("COLZ");
      
      // C9->cd();
      // distance_vs_theta->Draw("COLZ");
      
      // C10->cd();
      // E_Compton1_vs_theta->Draw("COLZ");
      
      // C11->cd();
      // E_Compton2_vs_theta->Draw("COLZ");
      
      // C12->cd();
      // E_Compton1_vs_distance->Draw("COLZ");
      
      // C13->cd();
      // depthCompton3->Draw();
      
      // C14->cd();
      // E_Compton3->Draw();
      
      // C15->cd();
      // E_Compton3_vs_E_Compton2->Draw("COLZ");
      
      // C16->cd();
      // E_Compton3_vs_E_Compton1->Draw("COLZ");
      
      // C17->cd();
      // E_Compton3_vs_theta->Draw("COLZ");
      
      // C18->cd();
      // ratioEdep2Edep3_vs_Edep2->Draw("COLZ");
      
      // C19->cd();
      // E_Compton3_vs_E_Compton2_E_Compton1_180keV_300keV->Draw("COLZ");
}

void SetLeafAddress(TTree* ntuple, const char* name, void* address)
{
  TLeaf* leaf = ntuple->FindLeaf(name);
    
  if (!leaf)
  {
    std::cerr << "Error in <SetLeafAddress>: unknown leaf --> " << name
     << std::endl;

    return;
  }

  leaf->SetAddress(address);
}
